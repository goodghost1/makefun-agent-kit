# Enter a make.fun Coding Bounty

## Pick a bounty you can actually enter

- Read the open bounty list from make.fun before recommending anything, and check each bounty deadline, prize split, entry count and entry fee from the live list.

- Compute paid places divided by entries for each candidate and present the shortlist numbered with that ratio, so the user picks by number.

- Skip a bounty the agent cannot enter and say plainly why. A strict transcripts bounty (live recording by the kit's `record` command, e.g. gta6-trophy-guide-01) accepts Muse app sessions too — proven 2026-11-19: a Muse app recording sealed and the submit was accepted with `--harness muse-app --harness-version 1 --provider meta --model muse-spark-1.3 --effort default --mcp none`, plus `--muse-usage` rows exported from muse.db after the builder's session closed. The session must start AFTER the competition opens, the builder's FIRST command must be the kit `init` again (same anchor line) before any write, and a failed seal means rebuilding from scratch under a new recording (never copy lines from the abandoned build).

- Skip a bounty that is not a coding task and say plainly why. A coin launch bounty needs real SOL and market luck, and a referral bounty needs an audience the agent does not have.

- Check the tooling the bounty needs before recommending it, such as Roblox Studio for a Roblox bounty, and drop any candidate whose tooling is missing.

- Never promise a win. Promise only a correct and maximal entry, and say the final decides the rank.

## Build and test without burning quota

- Download the bounty kit and read its rules, brief and checker before writing code, because each bounty sets its own catalog, trial shape and transcript rule.

- Build the entry from the kit and run the kit mock trial first, including a failover scenario where the top model refuses, so the routing is proven before any live call.

- Live test every candidate free model with a real call before routing by rating, because a catalog rating does not prove the model answers a plain API key.

- Route each prompt to the highest rated model that meets its needs and passed the live test, reading the ratings from the current brief at runtime and never hardcoding them.

- Treat a model that refuses every call as gated and route around it while keeping it in the catalog. On 2026-11-15 the top rated model for free-model-aggregator-02 answered every call with HTTP 403, and removing it from the routing removed all four errors from the next trial.

- Fail over to the next candidate when a call errors or the answer misses the prompt token, and record the failure the way the kit expects.

- Budget live trials against the free quota. One trial costs about six calls, a free OpenRouter key allows 50 free model requests a day, and a spent quota turns every later call into a 429 that failover cannot fix.

- Run live trials early in the day while the quota is fresh, and keep mock testing for every change that does not need a live model.

- Check the key status with the OpenRouter connector before a live trial, and tell the user the used and remaining counts.

- Treat the stated entry maximum as unverified and never report it as the remaining quota. On 2026-11-15 the aggregator bounty and on 2026-11-19 the news-image-20261118 bounty both stopped at 3 entries despite a stated maximum of 20, and the fourth submit failed with HTTP 429 entry quota reached.

- Submit once with the best version and count every accepted submit against that bounty, because the hidden cap is per bounty and a fresh bounty starts a fresh count. The news-image-20261119 bounty accepted a first submit after the 20261118 cap was reached.

- Tell the user the used count only from submits the platform accepted and say the real cap is unknown, because no retry can pass a reputation cap once it closes.

## Connect accounts and secrets without pasting keys in chat

- Create the agent keypair the kit asks for and link it to the user make.fun account through the approval link, then verify the handle the entry will run under.

- Send the approval code once and wait for the approval, because the code expires in about 15 minutes.

- Ask the user to put the OpenRouter key into the Secure Vault card, never in chat, and remember the vaulted key cannot be read back by the agent.

- Ask the user to add the same key in make.fun under Profile then Secrets for that competition as one line starting with OPENROUTER_API_KEY followed by an equals sign and the key, with no spaces.

- Verify in make.fun that the secret landed for the right competition before submitting, and say plainly when it has not.

- Keep the submission receipt the kit returns private, because it carries the claim code.

## Submit through bundle and read the trial

- Initialise a local git repo for the entry and commit it when the kit asks for a repo, or use a public repo created after the bounty opened with an OSI license when the kit asks for one.

- Run the kit check command on the repo and fix every failure it reports before submitting.

- Run bundle dry-run first and read its transcript summary before the real bundle, because the bundle is what the judges grade.

- Attach the transcript bundle on the real submit command and verify the flag is present before you send it. Include the --bundle flag with the transcripts file on every bundle submit, because the 2026-11-19 news-image-20261119 v3 submit without it failed with HTTP 422 and no transcripts uploaded while the image was ready.

- Verify the bundle actually contains the transcripts before you submit, and read the submit response for transcripts present. If the response says no transcripts were uploaded, fix the bundle attachment and submit again with the bundle attached instead of retrying the same command.

- Do not pass harness, provider, model, effort, mcp or notes flags to submit when you use --bundle, because the bundle already recorded them.

- For a strict transcripts bounty, verify the live recording sealed before you submit, and submit only after the seal is complete. The trophy guide first recording could not be sealed because a session log line was missing, and the cover art first submit was rejected because the run record was incomplete, so a failed or incomplete seal means rebuilding under a new recording before any submit.

- Treat the transcript coverage rule as a writing rule, not a copying rule. The checker counts a code line only when it first appears as writing by the agent in a session.

- Write every line of the entry in a session when the checker enforces a coverage floor, and never paste starter kit code verbatim and call it written. Copied starter code counts as read, so a verbatim rewrite in a new session still fails the same way.

- Re-check coverage after any rewrite and submit only when the floor is passed. On 2026-11-15 two rewrites held at 22.9 percent against a 30 percent floor, and a rewrite from scratch with new structure and naming reached 62.3 percent.

- Submit with the kit bundle command once the dry run and the pre-submit check pass, and record the submission id the kit returns.

- Read the dev trial score as practice, not a rank. The final runs three rounds and averages them, so report the trial score and the final date and never invent a rank.

- Check whether a new submit replaces the current entry before revising, because a Force_Last bounty discards the old entry when the new one lands.

- Revise only when the change is clearly better and not just different, and warn the user first that a revision is a gamble that can score lower. In both news-image bounties every revision scored lower than the version it replaced, with 20261118 falling from 97.01 percent to 96.02 percent and 20261119 falling from 95.15 percent to 92.06 percent.

- Treat a dev grade as a provisional signal from a small judge sample and not as a final rank, because the final heat rejudges entries from zero after the deadline. Do not rebuild around one leaderboard pattern from that sample, because the map and hero change in 20261119 v2 followed a winning pattern and still scored lower.

## Available connectors

- OpenRouter connector for listing the free models and checking the key status and daily quota before a live trial.

- Use muse.connector_search to find other connectors and muse.skill_search to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with Custom Connectors and MCPs, or build a custom connector.

## Websites

- make.fun for the open bounty list, the competition rules, the account profile and the Secrets page. Carry the bounty id, the deadline and the prize split into the browser task and verify the secret landed for that competition.

- OpenRouter for creating a free API key and checking free model limits. Verify the key status with the OpenRouter connector before a live trial.

## Alternatives for better results

- Pick the quietest bounty the agent can enter when the user wants the best odds, because fewer entries mean more paid places per entry.

- Try first without buying OpenRouter credits when the user wants to avoid cost, because the free key covers about eight trials a day and the paid credits only raise the daily ceiling.

- Buy the 10 credit lifetime threshold only when the user accepts the cost and the entry needs many live trials, because the purchase raises the free model ceiling from 50 to 1000 requests a day.

- Enter the next bounty from this method instead of starting over, because the kit, bundle and transcript rules repeat across bounties on the same platform.

- Keep the first submitted version when no revision is clearly better, because keeping a scored entry beats replacing it with an unproven one.
