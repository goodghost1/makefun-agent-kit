---
name: bug-bounty
description: Use when the user wants to hunt bug bounties (web or smart contract), pick a platform/program, learn the methodology, write a report, or check scope and severity rules. Covers HackerOne, Bugcrowd, Intigriti, YesWeHack, Immunefi, and audit contests (Sherlock, Cantina, CodeHawks).
---

# Bug bounty hunting (learned 2026-11-15, research in ~/workspace/research_notes/bug-bounty-research-20261115-0520/report.md)

User context: Indonesian, strong web3/BSC background (smart contracts, wallets, on-chain analysis), new to web bug bounty. Web is the faster first-income path; web3 is the higher ceiling and the user's edge.

## Platforms (pick ONE first, reputation compounds there)
- **Web:** HackerOne (largest; most programs + disclosed reports to study; paid $81m Jul 2024–Jun 2025, $89.1m Jul 2025–Jun 2026) and Bugcrowd (VRT scale P1–P5, not CVSS). Intigriti and YesWeHack are EU-based, EUR, often less crowded. Start on HackerOne + Bugcrowd.
- **Web3:** Immunefi (> $140m paid Oct 2026; record Wormhole $10m; LayerZero max $15m; but median critical only $20k — ceilings are not expectations). Crits typically 5–10% of funds at risk.
- **Contests (beginner-friendly — duplicates split, so valid findings still pay):** Sherlock (median pool ~$152,608), Cantina, Immunefi competitions, CodeHawks. **Code4rena is winding down in 2026 — do not build a plan around it.**
- For BSC specifically: programs are per-protocol, not per-chain. Look for BSC-deployed protocols on Immunefi and web programs of crypto companies on HackerOne/Bugcrowd. Fork BSC mainnet locally with Foundry/Anvil for PoCs.

## Hard rules (never break)
- Scope is an allow-list: only test assets the program page explicitly lists. Anything unlisted is off-limits, even a sibling domain.
- Never DoS, never exfiltrate or destroy data, never access other real users' data beyond the minimum PoC, never test live mainnet/testnet contracts (local fork only on Immunefi), never disclose before a fix, never social-engineer or phish.
- Safe harbour only covers in-scope, good-faith testing. Read the whole program policy (scope, out-of-scope, safe harbour, forbidden techniques, rate limits) before a single request.
- One vulnerability per report. If two bugs chain into one impact, report the chain as one report.

## Severity
- **Web (CVSS 3.1):** Critical 9.0–10.0, High 7.0–8.9, Medium 4.0–6.9, Low 0.1–3.9. Quote the CVSS vector in the report (e.g. `AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N` = 6.5 Medium), don't just assert a number. Bugcrowd uses its own VRT (P1–P5) — map the bug to the VRT entry first.
- **Immunefi (impact-first, NOT CVSS):** Critical = direct theft / permanent freezing / unauthorised minting / protocol insolvency; High = unclaimed yield / temporary freezing; Medium = griefing / unbounded gas; Low = no loss. Argue funds at risk + impact category, not a CVSS score.

## Web methodology
1. Recon: subfinder/amass → httpx → gau/katana → ffuf → nuclei → Burp manual testing.
2. Map the app with TWO test accounts (yours only) — IDOR/broken access control is the most lucrative beginner class (35.7% High/Critical).
3. High-value classes: IDOR/BOLA, SSRF, XSS (stored/reflected/DOM), SQLi, auth/session flaws (ATO), business logic flaws, API/BOLA.
4. Automation finds what everyone found. Manual testing + a reproducible report is what pays. Chained bugs beat scanner output.
5. Report lifecycle: submit → triage → confirmed → fix → resolved → bounty → disclosure. Duplicate = first reporter only. Informative = valid but no demonstrated impact/PoC.

## Web3 methodology
- Common vulns: reentrancy (incl. read-only), access control, oracle manipulation, flash loan attacks, unchecked external calls, integer/precision issues, signature replay, front-running/MEV.
- Tools: Slither, Aderyn, Mythril, Foundry, Echidna/Medusa. PoC = a Foundry test on a local fork, not a screenshot.
- Start with a contest, not a standing bounty: codebase frozen at a commit, duplicates pay, judging feedback teaches severity.

## Beginner roadmap (6 phases)
1. PortSwigger Web Security Academy (free, 273 labs) — start here.
2. OWASP Juice Shop + DVWA (practice apps).
3. TryHackMe / HackTheBox (guided labs).
4. Damn Vulnerable DeFi + Ethernaut (web3).
5. Pick VDP-first / wide-scope public programs; read disclosed reports (Hacktivity) before hunting.
6. Write reports with: summary, impact, reproduction steps, PoC, CVSS vector (web) or funds at risk (web3).

## Beginner mistakes to avoid
- Testing out of scope; scanner dumps with no PoC; bundling unrelated bugs; inflated CVSS with no justification; chasing only criticals (first paid bug is usually a low/medium IDOR or XSS); spreading across 4 platforms at once; AI-generated low-quality reports (curl ended its HackerOne bounty Jan 2026; valid rate fell from ~15% to <5%).
- Expect $0 for 3–6 months. Early valid (even Low) reports build the reputation that unlocks private programs, where competition is ~10x lower.

## When the user says they want to hunt
Ask one question first: web track, web3 track, or both — and whether they already have platform accounts. Then pick ONE program together, read its policy end-to-end, and start with recon. Never test anything without an in-scope program the user (or the program) has authorised.
